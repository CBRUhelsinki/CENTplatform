#ifndef MAIN_WINDOW_COMMON_H
#define MAIN_WINDOW_COMMON_H

namespace CENT
{
	namespace Menu
	{
		const char* const SESSION_NOTES_ACTION_NAME = "Session Notes";
		const char* const TOOLS_MENU_NAME           = "Tools";
		const char* const HELP_MENU_NAME            = "Help";
	}
}

#endif // MAIN_WINDOW_COMMON_H
