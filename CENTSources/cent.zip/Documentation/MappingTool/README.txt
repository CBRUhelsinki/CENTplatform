Mapping Tool is a command line application which create mapping between hashes and real patient�s names. It is very simple to use:

    MappingTool.exe K:\\PatientsFolder

Application will create a text file in current directory, with following structure:

    [patient name];[encrypted patient name]

You find MappingTool in MappingToolPackage.zip with QtCore4.dll which is required to run this application.