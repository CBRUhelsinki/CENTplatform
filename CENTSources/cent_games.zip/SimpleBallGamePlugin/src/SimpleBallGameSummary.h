#ifndef SimpleBALLGAMESUMMARY_H
#define SimpleBALLGAMESUMMARY_H

#include <QObject>

class SimpleBallGameSummary : public QObject
{
	Q_OBJECT

public:
	SimpleBallGameSummary(QObject *parent=0);
	~SimpleBallGameSummary();

private:
	
};

#endif // SimpleBALLGAMESUMMARY_H
