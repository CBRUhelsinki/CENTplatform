#include "SimpleBallGameSummary.h"

//TODO: not yet implemented

SimpleBallGameSummary::SimpleBallGameSummary(QObject *parent)
	: QObject(parent)
{

}

SimpleBallGameSummary::~SimpleBallGameSummary()
{

}
