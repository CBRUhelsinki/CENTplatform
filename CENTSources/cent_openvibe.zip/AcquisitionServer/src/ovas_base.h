#ifndef __OpenViBE_AcquisitionServer_Base_H__
#define __OpenViBE_AcquisitionServer_Base_H__

#include "ovas_defines.h"

#include <openvibe/ov_all.h>
#include <openvibe-toolkit/ovtk_all.h>

#endif // __OpenViBE_AcquisitionServer_Base_H__
